Roster App — Portable ZIP

Files:
- index.html — React version (runs locally). Uses React UMD + Babel + Tailwind CDN. Just open in a browser.
- roster-preview.html — Static HTML grid preview.
- (No build step required.)

How to use:
1) Double–click index.html
2) Add blocks by clicking empty slots.
3) Drag the black bars on a selected block to resize.
4) Autogenerate fills in tours, breaks, and front desk coverage.
5) Download CSV exports the visible timetable.

Deploying:
- You can host index.html on any static host (S3, Netlify, Vercel, GitHub Pages).
